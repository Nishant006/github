package com.tcs.dupont.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tcs.dupont.DAO.RegisterDAO;
import com.tcs.dupont.bean.RegisterBean;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		String eId = request.getParameter("eId");
		String  eName  =  request.getParameter("eName");
		String  password  =  request.getParameter("password");
		String  Cpassword  =  request.getParameter("Cpassword");
		String  bUnit  =  request.getParameter("bUnit");
		String  loc  =  request.getParameter("loc");
		
		HttpSession session = request.getSession();

		
    	   RegisterBean registerBean = new RegisterBean();
    	   
    	   if(eId != null && !eId.isEmpty()) {
    		   registerBean.seteId(eId);
    	   }
    	   if(eName != null && !eName.isEmpty()) {
    		   registerBean.seteName(eName);
    	   }
    	   if(password != null && !password.isEmpty()) {
    		   registerBean.setPassword(password);
    	   }
    	   if(Cpassword != null && !Cpassword.isEmpty()) {
    		   registerBean.setCpassword(Cpassword);
    	   }
    	   if(bUnit != null && !bUnit.isEmpty()) {
    		   registerBean.setbUnit(bUnit);
    	   }
    	   if(loc != null && !loc.isEmpty()) {
    		   registerBean.setLoc(loc);
    	   }
    
    	   
    	   RegisterDAO registerDao = new RegisterDAO();
    	   int status = registerDao.checkRegister(registerBean);
    	   session.setAttribute("status", status);
    	   if(status==1)
    	   {
    		   
    		   response.sendRedirect("home.jsp");
    	   }
    	   else
    	   {
    		  	   
    		   response.sendRedirect("register.jsp");
    	   }
    	   	
	    }

}