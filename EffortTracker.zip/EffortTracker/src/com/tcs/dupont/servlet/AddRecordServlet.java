package com.tcs.dupont.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.tcs.dupont.DAO.AddRecordDAO;
import com.tcs.dupont.bean.AddRecordBean;

/**
 * Servlet implementation class AddRecordServlet
 */
public class AddRecordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddRecordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//String  sNo  =  request.getParameter("sNo");
		String  bUnit1  =  request.getParameter("bUnit1");
		String loc1 = request.getParameter("loc1");
		String  eId1  =  request.getParameter("eId1");
		String  eName1  =  request.getParameter("eName1");
		String  eCategory  =  request.getParameter("eCategory");
		String  appId  =  request.getParameter("appId");
		String  appName  =  request.getParameter("appName");
		String  phase  =  request.getParameter("phase");
		String  actDetail  =  request.getParameter("actDetail");
		String  noh  =  request.getParameter("noh");
		String  com  =  request.getParameter("com");

		HttpSession session = request.getSession();


		AddRecordBean addRecordBean = new AddRecordBean();

		/*if(sNo != null || sNo != "") {
			addRecordBean.setsNo(sNo.trim());
		}*/
		if(bUnit1 != null &&   !bUnit1.isEmpty()) {
			addRecordBean.setbUnit1(bUnit1.trim());
		}
		if(loc1 != null && !loc1.isEmpty()) {
			addRecordBean.setLoc1(loc1.trim());
		}
		if(eId1 != null && !eId1.isEmpty()) {
			addRecordBean.seteId1(eId1.trim());
		}
		if(eName1 != null && !eName1.isEmpty()) {
			addRecordBean.seteName1(eName1.trim());
		}
		if(eCategory != null && !eCategory.isEmpty()) {
			addRecordBean.seteCategory(eCategory.trim());
		}
		if(appId != null && !appId.isEmpty()) {
			addRecordBean.setAppId(appId.trim());
		}
		if(appName != null && !appName.isEmpty()) {
			addRecordBean.setAppName(appName.trim());
		}
		if(phase != null && !phase.isEmpty()) {
			addRecordBean.setPhase(phase.trim());
		}
		if(actDetail != null && !actDetail.isEmpty()) {
			addRecordBean.setActDetail(actDetail.trim());
		}
		if(noh != null && !noh.isEmpty()) {
			addRecordBean.setNoh(noh.trim());
		}
		if(com != null && !com.isEmpty()) {
			addRecordBean.setCom(com.trim());
		}




		AddRecordDAO addRecordDao = new AddRecordDAO();
		int aCount = addRecordDao.saveRecord(addRecordBean);
		session.setAttribute("aCount", aCount);
		response.sendRedirect("addRecord.jsp");
	}

}
