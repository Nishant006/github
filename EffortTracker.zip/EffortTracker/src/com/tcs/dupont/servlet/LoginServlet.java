package com.tcs.dupont.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tcs.dupont.DAO.LoginDAO;
import com.tcs.dupont.bean.LoginBean;
import com.tcs.dupont.bean.RegisterBean;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		String uId = request.getParameter("id");
		String pWd   =  request.getParameter("password");
		
		HttpSession session = request.getSession();

       if((!(uId.equals(null) || uId.equals("")) && !(pWd.equals(null) || pWd.equals("")))){
		
    	   LoginBean loginBean = new LoginBean();
    	   loginBean.setuId(uId);
    	   loginBean.setpWd(pWd);
    	   
    	   LoginDAO loginDao = new LoginDAO();
    	   int count = loginDao.checkLogin(loginBean);
    	   if(count==0)
    	   {
    		   session.setAttribute("count", count);
    		   response.sendRedirect("home.jsp");
    	   }
    	   else
    	   {
    		   
    		   RegisterBean registerBean = loginDao.getUserDetails(loginBean);
    		   session.setAttribute("uid", registerBean.geteId());
    		   session.setAttribute("name", registerBean.geteName());
    		   session.setAttribute("bunit", registerBean.getbUnit());
    		   session.setAttribute("loc", registerBean.getLoc());
    		   session.setAttribute("accessRight", registerBean.getuRight());
    		   response.sendRedirect("addRecord.jsp");
    	   }
    	   
    	   
    	   
		
	    }

}
}
