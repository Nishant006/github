package com.tcs.dupont.java;



import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

import com.tcs.dupont.bean.AddRecordBean;

public class DownloadRecord {
public String exportToExcel(List<String> myList) throws Exception {
    
	
		HSSFWorkbook workbook = new HSSFWorkbook();
	    HSSFSheet spreadsheet = workbook.createSheet("Daily Tracker");
	    HSSFCellStyle style = workbook.createCellStyle();
	    style.setBorderBottom((short) 1); // single line border
	    style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
	    //style.setFillBackgroundColor(HSSFColor.ROYAL_BLUE.index);
	    style.setFillPattern(HSSFCellStyle.NO_FILL);
	    HSSFFont font = workbook.createFont();
	    font.setFontName(HSSFFont.FONT_ARIAL);
	    font.setFontHeightInPoints((short) 12);
	    font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	    font.setColor(HSSFColor.BLACK.index);
	    style.setFont(font);
	    
	    HSSFRow row = spreadsheet.createRow(0);
	    HSSFCell cell;
	    cell = row.createCell(0);
	    cell.setCellValue("S.No");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(1);
	    cell.setCellValue("Team");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(2);
	    cell.setCellValue("Location");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(3);
	    cell.setCellValue("Emp ID");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(4);
	    cell.setCellValue("Emp Name");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(5);
	    cell.setCellValue("Date");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(6);
	    cell.setCellValue("Effort Category");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(7);
	    cell.setCellValue("APP ID");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(8);
	    cell.setCellValue("Application Name");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(9);
	    cell.setCellValue("Phase");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(10);
	    cell.setCellValue("Activity Detail");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(11);
	    cell.setCellValue("No of Hours");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
	    cell = row.createCell(12);
	    cell.setCellValue("Comments");
	    cell.setCellStyle(style);        
	    spreadsheet.autoSizeColumn((short) 1);
    
        
	    for(int cnt=0,cnt1=1;cnt<myList.size();cnt++,cnt1++)
	    {
	    	
		    Object obj = myList.get(cnt);
			AddRecordBean addRecord =new AddRecordBean();
			addRecord = (AddRecordBean)obj;
    
	        row = spreadsheet.createRow(cnt1);
	        cell = row.createCell(0);
	        cell.setCellValue(cnt1);
	        cell = row.createCell(1);
	        cell.setCellValue(addRecord.getbUnit1());
	        cell = row.createCell(2);
	        cell.setCellValue(addRecord.getLoc1());
	        cell = row.createCell(3);
	        cell.setCellValue(addRecord.geteId1());
	        cell = row.createCell(4);
	        cell.setCellValue(addRecord.geteName1());
	        cell = row.createCell(5);
	        cell.setCellValue(addRecord.getDate());
	        cell = row.createCell(6);
	        cell.setCellValue(addRecord.geteCategory());
	        cell = row.createCell(7);
	        cell.setCellValue(addRecord.getAppId());
	        cell = row.createCell(8);
	        cell.setCellValue(addRecord.getAppName());
	        cell = row.createCell(9);
	        cell.setCellValue(addRecord.getPhase());
	        cell = row.createCell(10);
	        cell.setCellValue(addRecord.getActDetail());
	        cell = row.createCell(11);
	        cell.setCellValue(addRecord.getNoh());
	        cell = row.createCell(12);
	        cell.setCellValue(addRecord.getCom());
	    }
	    
	 String filePath = "C:/Effort/MemberWiseDailyEffortTracking.xls";    
	 File file = new File(filePath);
	 if(file.getParentFile().mkdirs() == false)
	 {
		 file.getParentFile().mkdirs();
	 }
    FileOutputStream out = new FileOutputStream(new File(filePath));
    workbook.write(out);
    out.close();
    System.out.println("MemberWiseDailyEffortTracking.xls written successfully");
    return "Success";
 }
}