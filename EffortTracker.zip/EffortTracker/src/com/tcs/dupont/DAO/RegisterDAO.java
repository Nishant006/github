package com.tcs.dupont.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.tcs.dupont.bean.RegisterBean;
import com.tcs.dupont.db.DBConnectionManager;

public class RegisterDAO {
  
	
	static Connection con=null;
	PreparedStatement ps = null;
	
	public int checkRegister(RegisterBean registerBean) {
		
		int status =0;

		try {
			String sql1 = "insert into user_info(emp_id,emp_name,emp_pass,business_unit,location) values(?,?,?,?,?)";
			
			
			con = DBConnectionManager.getConndb();
			ps = con.prepareStatement(sql1);
			
			ps.setString(1, registerBean.geteId());
			ps.setString(2, registerBean.geteName());
			ps.setString(3, registerBean.getPassword());
			ps.setString(4, registerBean.getbUnit());
			ps.setString(5, registerBean.getLoc());
			
			status = ps.executeUpdate();
			
		}
		catch(Exception sqe)
		{
			sqe.printStackTrace();
			
		} 
		finally {
			
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	return status; 

		
	}

}
