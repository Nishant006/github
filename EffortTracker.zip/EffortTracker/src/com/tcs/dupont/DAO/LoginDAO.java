package com.tcs.dupont.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tcs.dupont.bean.LoginBean;
import com.tcs.dupont.bean.RegisterBean;
import com.tcs.dupont.db.DBConnectionManager;

public class LoginDAO {
	static Connection con=null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public int checkLogin(LoginBean loginBean) {
       int count =0;

		try {
			String sql = "select count(1) from user_info where emp_id=? and emp_pass=?";
			
			con = DBConnectionManager.getConndb();
			ps = con.prepareStatement(sql);
			ps.setString(1, loginBean.getuId());
			ps.setString(2, loginBean.getpWd());
			rs = ps.executeQuery();
			while(rs.next())
			{
				count = rs.getInt(1);
			}
		}
		catch(Exception sqe)
		{
			sqe.printStackTrace();
		} 
		finally {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	return count; 

}
	
	public RegisterBean getUserDetails(LoginBean loginBean)
	{
		RegisterBean registerBean = null;
		try {
			
			
			
            String sql = "select emp_id,emp_name,business_unit,location,access_right from user_info where emp_id=?";
			
			con = DBConnectionManager.getConndb();
			ps = con.prepareStatement(sql);
			ps.setString(1, loginBean.getuId());
			
			rs = ps.executeQuery();
			while(rs.next())
			{
				registerBean =  new RegisterBean();
				registerBean.seteId(rs.getString(1));
				registerBean.seteName(rs.getString(2));
				registerBean.setbUnit(rs.getString(3));
				registerBean.setLoc(rs.getString(4));
				registerBean.setuRight(rs.getString(5));
			}
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
			
		}finally {
			
			
		}
		return registerBean;
		
	}
	
	

}
