package com.tcs.dupont.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tcs.dupont.bean.AddRecordBean;
import com.tcs.dupont.db.DBConnectionManager;

public class AddRecordDAO {

	

	public int saveRecord(AddRecordBean addRecordBean){
		int aCount=0;
		Connection con=null;
		PreparedStatement ps = null;
		try{
			String sql2 = "insert into task_info(business_unit,location,emp_id,emp_name,effort_category,app_id,app_name,phase,activity_details,no_of_hours,comment) values(?,?,?,?,?,?,?,?,?,?,?)";

			con = DBConnectionManager.getConndb();
			ps = con.prepareStatement(sql2);

			//ps.setString(1, addRecordBean.getsNo());
			ps.setString(1, addRecordBean.getbUnit1());
			ps.setString(2, addRecordBean.getLoc1());
			ps.setString(3, addRecordBean.geteId1());
			ps.setString(4, addRecordBean.geteName1());
			ps.setString(5, addRecordBean.geteCategory());
			ps.setString(6, addRecordBean.getAppId());
			ps.setString(7, addRecordBean.getAppName());
			ps.setString(8, addRecordBean.getPhase());
			ps.setString(9, addRecordBean.getActDetail());
			ps.setString(10, addRecordBean.getNoh());
			ps.setString(11, addRecordBean.getCom());

			aCount = ps.executeUpdate();
		}
		catch(Exception sqe)
		{
			sqe.printStackTrace();
		} 
		finally {
			try {
				ps.close();
				//con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return aCount; 
	}

	public List getAllRecords(String uid,String accessRight){
		List list=null;
		Connection con=null;
		PreparedStatement ps = null;
		try{
			String  sql3 = null;
			list=new ArrayList();
			if(accessRight.equals("U")) {
				sql3 = "Select * from task_info where emp_id =?";	
				
			}
			else {
				sql3 = "Select * from task_info order by date,emp_id";
			}
			con = DBConnectionManager.getConndb();
			ps = con.prepareStatement(sql3);
			if(accessRight.equals("U")) {
				ps.setString(1, uid);
			}
			ResultSet rs=ps.executeQuery();

			while(rs.next()){
				AddRecordBean u=new AddRecordBean();
				u.setsNo(rs.getString("s_no"));
				u.setbUnit1(rs.getString("business_unit"));
				u.setLoc1(rs.getString("location"));
				u.seteId1(rs.getString("emp_id"));
				u.seteName1(rs.getString("emp_name"));
				u.setDate(rs.getString("date"));
				u.seteCategory(rs.getString("effort_category"));
				u.setAppId(rs.getString("app_id"));
				u.setAppName(rs.getString("app_name"));
				u.setPhase(rs.getString("phase"));
				u.setActDetail(rs.getString("activity_details"));
				u.setNoh(rs.getString("no_of_hours"));
				u.setCom(rs.getString("comment"));

				list.add(u);
			}
		}catch(Exception e){
         e.printStackTrace();
		}
		finally {
			try {
				ps.close();
				//con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		return list;
	}
	
	public int deleteRecord(AddRecordBean u) {
		int count =0;
		PreparedStatement ps = null;
		Connection con=null;
		try{
			
			con = DBConnectionManager.getConndb();
			ps=con.prepareStatement("delete from task_info where s_no=? and emp_id=?");
			ps.setString(1,u.getsNo());
			ps.setString(2,u.geteId1());
			
			count = ps.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
			
			}
		    finally {
		    	try {
					ps.close();
					//con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		    	
		    	
		    }
       return count;
	}
	
	public AddRecordBean getRecord(AddRecordBean u1){
		Connection con=null;
		PreparedStatement ps = null;
		AddRecordBean u =null;
		try{
			String  sql3 = "Select * from task_info where s_no=? and emp_id=?";
			con = DBConnectionManager.getConndb();
			ps = con.prepareStatement(sql3);	
			ps.setString(1,u1.getsNo());
			ps.setString(2,u1.geteId1());
			ResultSet rs=ps.executeQuery();

			while(rs.next()){
				u=new AddRecordBean();
				u.setsNo(rs.getString("s_no"));
				u.setbUnit1(rs.getString("business_unit"));
				u.setLoc1(rs.getString("location"));
				u.seteId1(rs.getString("emp_id"));
				u.seteName1(rs.getString("emp_name"));
				u.setDate(rs.getString("date"));
				u.seteCategory(rs.getString("effort_category"));
				u.setAppId(rs.getString("app_id"));
				u.setAppName(rs.getString("app_name"));
				u.setPhase(rs.getString("phase"));
				u.setActDetail(rs.getString("activity_details"));
				u.setNoh(rs.getString("no_of_hours"));
				u.setCom(rs.getString("comment"));

			}
		}catch(Exception e){
         e.printStackTrace();
		}
		finally {
			try {
				ps.close();
				//con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		return u;
	}
	
	public int update(AddRecordBean u){
		int uStatus=0;
		Connection con=null;
		PreparedStatement ps = null;
		try{
			String sql4 ="update task_info set effort_category=?,app_id=?,app_name=?,phase=?,activity_details=?,no_of_hours=?,comment=? where s_no=? and emp_id=?";
			con = DBConnectionManager.getConndb();
			ps = con.prepareStatement(sql4);
			ps.setString(1,u.geteCategory());
			ps.setString(2,u.getAppId());
			ps.setString(3,u.getAppName());
			ps.setString(4,u.getPhase());
			ps.setString(5,u.getActDetail());
			ps.setString(6,u.getNoh());
			ps.setString(7,u.getCom());
			ps.setString(8,u.getsNo());
			ps.setString(9,u.geteId1());
			uStatus=ps.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}
		return uStatus;
	}
}
