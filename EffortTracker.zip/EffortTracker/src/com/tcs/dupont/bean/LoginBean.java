package com.tcs.dupont.bean;

public class LoginBean {
	
	private String uId;
	private String pWd;
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
	public String getpWd() {
		return pWd;
	}
	public void setpWd(String pWd) {
		this.pWd = pWd;
	}
	

}
