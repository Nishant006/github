package com.tcs.dupont.bean;

import java.io.Serializable;

public class AddRecordBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String  sNo;
	private String  bUnit1;
	private String  loc1;
	private String  eId1;
	private String  eName1;
	private String  eCategory;
	private String  appId;
	private String  appName;
	private String  phase;
	private String  actDetail;
	private String  noh;
	private String  com;
	private String  date;

	public String getsNo() {
		return sNo;
	}
	public void setsNo(String sNo) {
		this.sNo = sNo;
	}
	public String getbUnit1() {
		return bUnit1;
	}
	public void setbUnit1(String bUnit1) {
		this.bUnit1 = bUnit1;
	}
	public String getLoc1() {
		return loc1;
	}
	public void setLoc1(String loc1) {
		this.loc1 = loc1;
	}
	public String geteId1() {
		return eId1;
	}
	public void seteId1(String eId1) {
		this.eId1 = eId1;
	}
	public String geteName1() {
		return eName1;
	}
	public void seteName1(String eName1) {
		this.eName1 = eName1;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String geteCategory() {
		return eCategory;
	}
	public void seteCategory(String eCategory) {
		this.eCategory = eCategory;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getPhase() {
		return phase;
	}
	public void setPhase(String phase) {
		this.phase = phase;
	}
	public String getActDetail() {
		return actDetail;
	}
	public void setActDetail(String actDetail) {
		this.actDetail = actDetail;
	}
	public String getNoh() {
		return noh;
	}
	public void setNoh(String noh) {
		this.noh = noh;
	}
	public String getCom() {
		return com;
	}
	public void setCom(String com) {
		this.com = com;
	}

}
