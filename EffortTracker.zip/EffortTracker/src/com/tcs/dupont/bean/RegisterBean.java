package com.tcs.dupont.bean;

public class RegisterBean {
	
	private String eId;
	private String eName;
	private String password;
	private String Cpassword;
	private String bUnit;
	private String loc;
	private String uRight;
	
	public String geteId() {
		return eId;
	}
	public void seteId(String eId) {
		this.eId = eId;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getbUnit() {
		return bUnit;
	}
	public void setbUnit(String bUnit) {
		this.bUnit = bUnit;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getCpassword() {
		return Cpassword;
	}
	public void setCpassword(String cpassword) {
		Cpassword = cpassword;
	}
	public String getuRight() {
		return uRight;
	}
	public void setuRight(String uRight) {
		this.uRight = uRight;
	}
	

}
