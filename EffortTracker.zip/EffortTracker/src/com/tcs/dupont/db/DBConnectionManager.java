package com.tcs.dupont.db;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBConnectionManager {
	static Connection connection =null;
	public static Connection getConnection() {
	
	InitialContext initialContext;
	 
	try {
		   initialContext = new InitialContext();
		   Context context = (Context) initialContext.lookup("java:comp/env/");
		    //The JDBC Data source that we just created
		    System.out.println("context"+context);	
		    DataSource ds = (DataSource) context.lookup("jdbc/testdb");
		    System.out.println("ds"+ds);
		    connection = ds.getConnection();
		    System.out.println("Connection"+connection);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return  connection;
  
	}
	public static Connection getConndb() {
		return connection;
	}
}

