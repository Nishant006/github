package com.tcs.dupont.listener;

import java.sql.Connection;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.tcs.dupont.db.DBConnectionManager;

/**
 * Application Lifecycle Listener implementation class AppContextListener
 *
 */
public class AppContextListener implements ServletContextListener {
    
	static Connection con = null;
	public void contextInitialized(ServletContextEvent servletContextEvent) {
		DBConnectionManager obj =  new DBConnectionManager();
		con = obj.getConnection();
		System.out.println("con==========="+con);
    	
    }

    public void contextDestroyed(ServletContextEvent servletContextEvent) {
    	
    	
    }
}
